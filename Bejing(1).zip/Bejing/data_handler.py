import pandas as pd

def load_and_merge_data(pm_file, meteo_file):
    pm_data = pd.read_csv(pm_file)
    meteo_data = pd.read_csv(meteo_file)
    merged_data = pd.merge(pm_data, meteo_data, on=['datetime'], how='inner')
    merged_data['datetime'] = pd.to_datetime(merged_data['datetime'])
    merged_data.set_index('datetime', inplace=True)
    return merged_data

def preprocess_data(df):
    df = df.dropna()
    return df
