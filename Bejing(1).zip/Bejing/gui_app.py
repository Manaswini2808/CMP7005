import streamlit as st
from data_handler import load_and_merge_data, preprocess_data
from eda_module import plot_histogram, plot_correlation_heatmap
from model_module import train_model

def run_gui():
    st.set_page_config(page_title="Air Quality Prediction App", layout="wide")
    st.title("Air Quality Prediction Using PM2.5 and Meteorological Data")

    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Select Page", ["Data Overview", "EDA", "Modeling & Prediction"])

    if page == "Data Overview":
        st.subheader("Upload Datasets")
        pm_file = st.file_uploader("Upload PM2.5 Data CSV", type=["csv"])
        meteo_file = st.file_uploader("Upload Meteorological Data CSV", type=["csv"])
        
        if pm_file and meteo_file:
            data = load_and_merge_data(pm_file, meteo_file)
            data = preprocess_data(data)
            st.dataframe(data.head())

    elif page == "EDA":
        st.subheader("Exploratory Data Analysis")
        column = st.text_input("Enter column name for histogram:")
        if st.button("Show Histogram"):
            plot_histogram(data, column)

        if st.button("Show Correlation Heatmap"):
            plot_correlation_heatmap(data)

    elif page == "Modeling & Prediction":
        st.subheader("Model Training and Evaluation")
        if 'data' in locals():
            model, mse, r2, _, _ = train_model(data, 'PM2.5')
            st.write(f"Mean Squared Error: {mse}")
            st.write(f"R² Score: {r2}")
        else:
            st.warning("Please upload and process data first on the 'Data Overview' page.")
