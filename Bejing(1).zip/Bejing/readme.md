# Air Quality Prediction App

This application allows users to:
- Upload and merge PM2.5 and meteorological data
- Perform exploratory data analysis (EDA)
- Train machine learning models
- Evaluate model performance

## Getting Started

1. Install dependencies:
