from gui_app import run_gui

if __name__ == "__main__":
    run_gui()
